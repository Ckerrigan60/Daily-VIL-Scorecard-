# VIL Daily Scorecards

Internal daily scorecard app for leadership performance tracking.

---

## How to Deploy to Vercel (One-Time Setup — ~5 minutes)

### Step 1 — Create a GitHub account (if you don't have one)
Go to https://github.com and sign up. It's free.

### Step 2 — Create a new GitHub repository
1. Click the **+** icon top right → **New repository**
2. Name it: `vil-scorecards`
3. Set it to **Private**
4. Click **Create repository**

### Step 3 — Upload the files
1. On the new repo page, click **uploading an existing file**
2. Drag and drop ALL the files and folders from this zip into the uploader
   - Make sure to include: `src/` folder, `index.html`, `package.json`, `vite.config.js`, `.gitignore`
3. Click **Commit changes**

### Step 4 — Deploy on Vercel
1. Go to https://vercel.com and sign up with your GitHub account
2. Click **Add New Project**
3. Find and select `vil-scorecards` from your GitHub repos
4. Vercel will auto-detect it as a Vite/React project
5. Leave all settings as default
6. Click **Deploy**

### Step 5 — Get your URL
After ~60 seconds, Vercel gives you a live URL like:
`https://vil-scorecards.vercel.app`

That's it. Share that URL with your VA. She bookmarks it, opens it every night, fills it in, saves, exports PDF.

---

## How data is stored
Data saves in the browser's local storage on whatever device the VA uses.
**Important:** Always use the same device/browser to keep history intact.
If you need to switch devices, use the Export PDF before switching.

---

## How to update the app
If you ever want to change targets or add fields, edit `src/App.jsx` in GitHub
and Vercel will automatically redeploy within 60 seconds.
